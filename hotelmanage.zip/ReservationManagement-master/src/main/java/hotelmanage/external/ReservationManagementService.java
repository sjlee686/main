package hotelmanage.external;




public class ReservationManagementService {


}
