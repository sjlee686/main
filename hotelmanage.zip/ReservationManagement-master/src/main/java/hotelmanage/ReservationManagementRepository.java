package hotelmanage;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface ReservationManagementRepository extends PagingAndSortingRepository<ReservationManagement, Integer>{


}