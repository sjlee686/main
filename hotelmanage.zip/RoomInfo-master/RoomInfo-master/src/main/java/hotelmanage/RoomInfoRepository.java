package hotelmanage;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface RoomInfoRepository extends PagingAndSortingRepository<RoomInfo, Integer>{


}
